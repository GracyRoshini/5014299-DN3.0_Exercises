// Main.java
public class Main {
    public static void main(String[] args) {
        Order[] orders = new Order[] {
            new Order(1, "John", 100.0),
            new Order(2, "Jane", 50.0),
            new Order(3, "Bob", 200.0),
            new Order(4, "Alice", 150.0)
        };

        System.out.println("Original orders:");
        for (Order order : orders) {
            System.out.println(order.getOrderId() + " " + order.getCustomerName() + " " + order.getTotalPrice());
        }

        BubbleSort.sortOrders(orders);
        System.out.println("Sorted orders (Bubble Sort):");
        for (Order order : orders) {
            System.out.println(order.getOrderId() + " " + order.getCustomerName() + " " + order.getTotalPrice());
        }

        QuickSort.sortOrders(orders);
        System.out.println("Sorted orders (Quick Sort):");
        for (Order order : orders) {
            System.out.println(order.getOrderId() + " " + order.getCustomerName() + " " + order.getTotalPrice());
        }
    }
}