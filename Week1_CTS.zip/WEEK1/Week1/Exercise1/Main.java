// Main.java
public class Main {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        Product product1 = new Product(1, "Product 1", 10, 9.99);
        Product product2 = new Product(2, "Product 2", 20, 19.99);

        inventory.addProduct(product1);
        inventory.addProduct(product2);

        System.out.println("Product 1 quantity: " + inventory.getProduct(1).getQuantity());
        System.out.println("Product 2 price: " + inventory.getProduct(2).getPrice());

        product1.setQuantity(15);
        inventory.updateProduct(product1);

        System.out.println("Updated Product 1 quantity: " + inventory.getProduct(1).getQuantity());

        inventory.deleteProduct(2);

        System.out.println("Product 2 is deleted: " + (inventory.getProduct(2) == null));
    }
}