public class Main {
    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();

        Task task1 = new Task(1, "Task 1", "In Progress");
        Task task2 = new Task(2, "Task 2", "Completed");
        Task task3 = new Task(3, "Task 3", "Pending");

        taskList.addTask(task1);
        taskList.addTask(task2);
        taskList.addTask(task3);

        System.out.println("All Tasks:");
        taskList.traverseTasks();

        Task foundTask = taskList.searchTask(2);
        if (foundTask != null) {
            System.out.println("Found task: " + foundTask.getTaskName());
        } else {
            System.out.println("Task not found.");
        }

        taskList.deleteTask(2);

        System.out.println("Tasks after deletion:");
        taskList.traverseTasks();
    }
}