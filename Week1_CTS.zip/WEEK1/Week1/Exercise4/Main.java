public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        Employee employee1 = new Employee(1, "John Doe", "Software Engineer", 50000.0);
        Employee employee2 = new Employee(2, "Jane Smith", "Marketing Manager", 70000.0);
        Employee employee3 = new Employee(3, "Bob Johnson", "Sales Representative", 40000.0);

        ems.addEmployee(employee1);
        ems.addEmployee(employee2);
        ems.addEmployee(employee3);

        System.out.println("All Employees:");
        ems.traverseEmployees();

        Employee foundEmployee = ems.searchEmployee(2);
        if (foundEmployee != null) {
            System.out.println("Found employee: " + foundEmployee.getName());
        } else {
            System.out.println("Employee not found.");
        }

        ems.deleteEmployee(2);

        System.out.println("Employees after deletion:");
        ems.traverseEmployees();
    }
}