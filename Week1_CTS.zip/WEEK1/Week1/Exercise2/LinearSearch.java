public class LinearSearch {
    public static Product search(Product[] products, int targetId) {
        for (Product product : products) {
            if (product.getProductId() == targetId) {
                return product;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Product[] products = new Product[5];
        products[0] = new Product(1, "Product 1", "Category 1");
        products[1] = new Product(2, "Product 2", "Category 2");
        products[2] = new Product(3, "Product 3", "Category 3");
        products[3] = new Product(4, "Product 4", "Category 4");
        products[4] = new Product(5, "Product 5", "Category 5");

        Product result = search(products, 3);
        if (result != null) {
            System.out.println("Product found: " + result.getProductName());
        } else {
            System.out.println("Product not found");
        }
    }
}